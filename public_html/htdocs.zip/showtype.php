<?php
// including important files
require_once($_SERVER['DOCUMENT_ROOT'] . 'function/session.php');
require_once($_SERVER['DOCUMENT_ROOT'] . 'function/database.php');
require_once($_SERVER['DOCUMENT_ROOT'] . 'function/account.php');
// detect is user logged in or not to handle voting system
if(!is_user_logged_in()) {
  $is_user_logged_in = 0;
} else {
  $is_user_logged_in = 1;
}
// detect active
if(get_user_meta('token') != "activated") {
  $is_user_activated = 0;
} else {
  $is_user_activated = 1;
}
// if there is no given parameter, better to redirect it
if(!isset($_GET['brand'])) {
  header("Location: $HOME_URL");
}
// getting data to be stored into variables from user
$brandUrl = strtolower($_GET['brand']);
$checkBrand = $conn->query("SELECT ID FROM post WHERE brand='$brandUrl'");
if($checkBrand->num_rows > 0) {
  $brandExist = 1;
} else {
  $brandExist = 0;
}
$brand = strtolower($_GET['brand']);
$WEB_DESC = "Berikut ini menampilkan foto-foto motor $brand yang telah diupload di IndoMotorART.
              IndoMotorART sendiri adalah website komunitas motor Indonesia.";
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title><?php echo ucfirst($brand) . " - " . $WEB_NAME?></title>
    <meta name="description" content="<?php echo $WEB_DESC ?>"/>
  </head>
  <body>

    <?php

    require_once('parts/top.php');
    ?>

    <div class="full-wrapper" id="main">
      <div class="container">
        <?php if($brandExist == 1) { ?>
        <div class="cat-title">
          <h2><?php echo ucfirst($brand) ?></h2>
        </div>
        <div class="post-list" id="brand">
          Loading...
        </div>
        <div id="msg-endpost">
        </div>
        <?php
        } else {
          echo '<h2>Brand tidak ditemukan.</h2>';
        }
        ?>
      </div>
    </div>

    <?php
    require_once('asset.php');
    require_once($_SERVER['DOCUMENT_ROOT'] . 'parts/bottom.php');
    ?>

  </body>
  <script type="text/javascript" src="http://indomotorart.com/function/post-feed.js"></script>
  <script type="text/javascript">

  $(document).ready(function() {
    // below is specialized only for new with autoload system
    var newStart = 0;
    var newLimit = 6;
    var newStarted = 0;
    var newMsg = "Maaf! Tidak ditemukan foto yang lebih lama.";
    var is_user_logged_in = <?php echo $is_user_logged_in ?>;
    var printed = 0;
    var reachesPageLimit = 0;

    function showMsgPageLimit() {
      console.log("ASDSADaMMM");
      reachesPageLimit = 1;
      if(reachesPageLimit == 1) {
        $("#msg-endpost").append("<a href='<?php echo $HOME_URL ?>/baru?post=" + (newStart) + "'>lihat yang lebih lama -></a>");
        $("#msg-endpost").fadeIn("fast");
        reachesPageLimit = 2;
      }
    }

    <?php
    // to control the pagination system
    if(!isset($_GET['post'])) {
      ?>

    $("#brand").html("");
    showPost("<?php echo $brand ?>", newLimit, "brand", "Maaf! Tidak ditemukan foto dengan brand <?php echo ucfirst($brand) ?>.", newStart, null, "brand");
    newStart += newLimit;
    printed += newLimit;
    $(window).scroll(function() {
      console.log(outRes);
        if(newStarted == 0) {
          if($(window).scrollTop() > $("html").height() - window.innerHeight - 350) {
            setTimeout(function() {
              newStarted = 1;
              console.log("triggered");
            }, 300);
          }
        }

        if(newStarted == 1) {
          if(outRes != 0 && printed < 20) {
            showPost("<?php echo $brand ?>", newLimit, "brand", newMsg, newStart, "msg-endpost", "brand");
            printed += newLimit;
          }
          if(outRes != 0 && printed >= 20) {
            if(reachesPageLimit == 0) {
              showMsgPageLimit();
            }
          }
          newStart += newLimit;
          newStarted = 0;
        }

    })

    <?php } else { ?>
      $("#new").html("");
      showPost("new", newLimit, "new", "Maaf! Tidak ditemukan foto baru.", newStart);
      newStart += newLimit;
      printed += newLimit;
      $(window).scroll(function() {
        console.log(outRes);
          if(newStarted == 0) {
            if($(window).scrollTop() > $("html").height() - window.innerHeight - 350) {
              setTimeout(function() {
                newStarted = 1;
                console.log("triggered");
              }, 300);
            }
          }

          if(newStarted == 1) {
            if(outRes != 0 && printed < 20) {
              showPost("new", newLimit, "new", newMsg, newStart, "msg-endpost");
              printed += newLimit;
            }
            if(outRes != 0 && printed >= 20) {
              if(reachesPageLimit == 0) {
                showMsgPageLimit();
              }
            }
            newStart += newLimit;
            newStarted = 0;
          }

      })
    <?php } ?>
  })
  // from StackOverFlow by Majid Golshadi https://stackoverflow.com/users/2603921/majid-golshadi the link:https://stackoverflow.com/a/20819663
  $(document).on('click', '.love-post', function() {
    console.log("Clicked");
    var postID = $(this).attr('data-loveid');
    var thisx = $(this);
    var loggedin = <?php echo $is_user_logged_in ?>;
    var activated = <?php echo $is_user_activated ?>;

    console.log(postID);
    if(loggedin == 0) {
      window.location.replace("http://indomotorart.com/login");
    } else if(activated == 0) {
      window.location.replace("http://indomotorart.com/akun/verifikasi");
    } else {
        $.ajax({
          type: "POST",
          url: "http://indomotorart.com/function/vote.php",
          dataType: "JSON",
          data: {postID : postID},
          success: function(r) {
            console.log(r);
            if(r == "unlogged") {
              window.location.replace("http://indomotorart.com/login");
            }
            if(r["updown"] == '1') {
              var total= r["total"];
              thisx.addClass("loved fa-heart");
              thisx.removeClass("fa-heart-o");
              thisx.html("" + total);
            } else if (r["updown"] == '-1') {
              var total= r["total"];
              thisx.removeClass("loved fa-heart");
              thisx.addClass("fa-heart-o");
              thisx.html("" + total);
            } else {
              alert("terjadi error");
            }
          }
        })
    }
  })
  $(document).on("dblclick", ".post-item", function() {
    console.log("ASDS")
    $(this).children('.bottom-post').children('.love-post').click();
    console.log("dblclicked");
  });
  </script>
</html>
