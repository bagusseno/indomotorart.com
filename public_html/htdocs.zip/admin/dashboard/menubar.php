<div class="menubar">
  <a href="<?php echo $HOME_URL ?>"<dl id="logo">
    <img src="http://indomotorart.com/asset/logo.png" id="logo"/>
  </dl></a>
  <hr>
  <dl id="menu">
    <ul>
      <li><a href="../dashboard">Dashboard</a></li>
      <li><a href="createpage.php">Create Page</a></li>
      <li><a href="post-list.php">Post List</a></li>
      <li><a href="page-list.php">Page List</a></li>
  </dl>
</div>
