<?php
// including important files
require_once($_SERVER['DOCUMENT_ROOT'] . '/function/session.php');
require_once($_SERVER['DOCUMENT_ROOT'] . '/function/database.php');
require_once($_SERVER['DOCUMENT_ROOT'] . '/function/account.php');
require_once($_SERVER['DOCUMENT_ROOT'] . '/asset.php');
// redirect if no parameter found
if(isset($_GET['keyword']) || isset($_GET['tag'])) {
} else {
  header("Location: $HOME_URL");
}
// getting parameter
$found = 0;
if(isset($_GET['keyword'])) {
  $title = "Search for $keyword";
  $kind = "search";
  $keyword = $_GET['keyword'];
  $dataKey = $conn->query("SELECT * FROM post WHERE title OR brand OR tipe OR modspec OR content LIKE '%$keyword%'") or mysqli_error($conn);
} elseif(isset($_GET['tag'])) {
  $kind = "tag";
  $keyword = $_GET['tag'];
  $dataKey = $conn->query("SELECT * FROM post WHERE tags LIKE '%$keyword%'") or mysqli_error($conn);
  foreach($dataKey as $line) {
    $tags = unserialize($line['tags']);
    $findTag = array_search("#" . $keyword, $tags);
    if(!$findTag) {
      unset($line);
      continue;
    } else {
      $found = 1;
    }
  }
  $title = "Search tag $keyword";
}
// get data and check the existence of the given page ID
if($dataKey->num_rows <=0) {
  $content = "<div>Search for $keyword tidak ditemukan<br><a href='$HOME_URL'>Kembali ke Beranda</a></div>";
} else {
  $content = "";
}

if($found == 0) {
  $content = "<div>Search for tag: $keyword tidak ditemukan<br><a href='$HOME_URL'>Kembali ke Beranda</a></div>";
}

?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title><?php echo strip_tags($title) ?> - <?php echo $WEB_NAME ?></title>
  </head>
  <body>

    <?php

    require_once($_SERVER['DOCUMENT_ROOT'] . '/parts/top/top-header-2.php');

    ?>
    <div class="full-wrapper" id="main">
      <div class="container">
        <div class="cat-title">
          <h1><?php echo $title ?></h1>
        </div>
        <div class="post-list" id="content">
        </div>
      </div>
    </div>
    <?php
    require_once('/parts/bottom.php');
    ?>
  </body>
  <script type="text/javascript" src="http://indomotorart.com/function/post-feed.js"></script>
  <script>
    showPost("all", 0, "content", "<?php echo $content ?>", 0, null, "<?php echo $kind ?>", "<?php echo $keyword ?>");
  </script>
</html>
