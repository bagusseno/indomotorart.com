<?php

  require_once($_SERVER['DOCUMENT_ROOT'] . "/function/database.php");
  require_once($_SERVER['DOCUMENT_ROOT'] . "/function/account.php");
  require_once($_SERVER['DOCUMENT_ROOT'] . "/function/session.php");

  if(isset($_POST['register'])) {
    $username = mysql_real_escape_string($_POST['username']);
    $password = mysql_real_escape_string($_POST['password']);
    $email    = mysql_real_escape_string($_POST['email']);

    // validating username
    if(preg_match("/\n/", $username) == 1) {
      echo 'userWhiteSpace';
      die;
    }

    if(!empty($username) && !empty($password) && !empty($email)) {

      //checking availability
      $checkUser = $conn->query("SELECT ID FROM user WHERE username='$username'");
      $checkEmail = $conn->query("SELECT ID FROM user WHERE email='$email'");
      $return = "already";
      $error = 0;

      if($checkUser->num_rows > 0) {
        $return .= 'User';
        $error++;
      }
      // if ($checkEmail->num_rows > 0) {
      //   $return .= 'Email';
      //   $error++;
      // }
      if($error == 0) {
        $token = $username.uniqid();
        $url = preg_replace("/[^a-zA-Z0-9 ]/", "", $username);
        $url = rtrim($url);
        $url = str_replace(" ", "-", $url);
        $url = strtolower($url);
        $newUser = $conn->query("INSERT INTO user (username, password, email, token, url) VALUES('$username', '$password', '$email', '$token', '$url')");
        if($newUser) {
          $headers = "From: " . strip_tags($email) . "\r\n";
          $headers .= "Reply-To: bagusseno354@gmail.com\r\n";
          $headers .= "MIME-Version: 1.0\r\n";
          $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
          mail($email, "Verifikasi E-mail Anda - IndoMotorStyle.com", "Verifikasi e-mail Anda, cukup klik: <a href='http://indomotorart.com/akun/verifikasi?token=$token'>http://indomotorart.com/akun/verifikasi?token=$token</a>", $headers);
          login($username, $password);
          echo 'success';
          die;
        } else {
          echo 'error';
          die;
        }
      } else {
        echo $return;
      }

    }

  }

?>
