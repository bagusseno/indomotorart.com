console.log("Included");
var outRes;
function showPost(type, limit, append, msg = null, start, autoloadAppend = null, kind = null, note = null) {
  $.ajax({
    type: "POST",
    url: "http://indomotorart.com/function/post-feed.php",
    data: {type: type, limit: limit, start: start, kind: kind, note: note},
    success: function(res) {
      console.log("ajaxed");
      if(res == "notfound") {
        if(autoloadAppend != null) {
          $("#" + autoloadAppend).html(msg);
          $("#" + autoloadAppend).fadeIn("fast");
        } else {
          $("#" + append).append(msg);
        }
        outRes = 0;
        return;
      }
      outRes = 1;
      console.log(res);
      res = JSON.parse(res);
      for(var i = 0; i < res.length; i++) {
        var loved = "";
        if(res[i].loved == '1') {
          loved = "fa-heart loved";
        } else {
          loved = "fa-heart-o";
        }
        if(kind == "admin") {
          crud = '<span class="delete-post">' +
          '<a class="delete-post-btn post-btn" id="' + res[i].ID +'">Hapus</a>' +
          '</span>';
        } else {
          crud = '<span class="comment-post post-btn">' +
          '<a class="comment-post-btn" href="showpost.php?url=' + res[i].url + '#comments">komentar</a>' +
          '</span>' +
          '<span class="more-post">' +
          '<a class="more-post-btn post-btn" href="http://indomotorart.com/showpost.php?url=' + res[i].url + '">detail</a>' +
          '</span>';
        }
        var post = '<div class="post-item new" id="post-' + res[i].ID +'">' +
        '<a href="showpost.php?url=' + res[i].url + '">' +
        '<div class="top-post post-overlay">' +
        '<span class="posttitle"><a href="showpost.php?url=' + res[i].url + '">' + res[i].title + '</a></span>' +
        '<br><small><a href="showprofile.php?user=' + res[i].userurl + '">  ' + res[i].nickname + ' (' + res[i].motor + ') (' + res[i].userTitle + ') (' + res[i].rep + ' rep)' + '</a></small>' +
        '</div>' +

        '<div class="bottom-post post-overlay">' +
        '<span data-loveid="' + res[i].ID + '" class="fa love-post ' + loved + '">' + res[i].love + '</span>' +

        '<span class="actions-post">' + crud +
        '</span>' +

        '</div>' +

        "<div class='post-thumb' style='background-image:url(" + res[i].imgsrc + ");'>" +

        "</div>" +

        "</a></div>";
        $("#" + append).append(post);
      }
    }
  })

}
