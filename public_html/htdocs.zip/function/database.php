<?php

$HOME_URL = "http://indomotorart.com";
$WEB_NAME = "IndoMotorART";
$WEB_DESC = "IndoMotorART adalah website galeri motor khususnya aliran custom Indonesia.
              IndoMotorART juga merupakan komunitas motor Indonesia, baik Yamaha, Kawasaki, Honda,
              maupun Suzuki.";
$conn = new mysqli("localhost", "root", "", "ims");

?>
