<div class="footer" id="footer">
  <div class="container">
    <span>Copyright 2017 - IndoMotorART</span>
  </div>
</div>
