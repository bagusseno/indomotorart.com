<?php

  require_once('/top/top-header.php');
  require_once('/top/top-intro.php');
  require_once('/top/mid-header.php');
  require_once($_SERVER['DOCUMENT_ROOT'] . "/parts/top/mid-header-mini.php");

?>
