<div class="full-wrapper" id="main">

  <div class="container">
    <div class="cat-title">
      <h2>Foto Populer</h2>
    </div>
    <div class="post-list" id="trending">

    </div>

    <div class="cat-title">
      <h2>Foto Baru</h2>
    </div>
    <div class="post-list" id="new">

    </div>
  </div>

</div>
