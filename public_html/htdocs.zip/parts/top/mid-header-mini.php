<header class="common-header mid-header-2 mid-header" id="mid-header-2">

  <div class="container">

    <span class="nav mid-nav menu-nav">
      <ul>
        <li><a href="<?php echo $HOME_URL ?>">Beranda</a></li>
        <li><a href="<?php echo $HOME_URL ?>/populer">Foto Populer</a></li>
        <li><a href="<?php echo $HOME_URL ?>/baru">Foto Baru</a></li>
        <li><a href="<?php echo $HOME_URL ?>/showtype.php?brand=Honda">Honda</a></li>
        <li><a href="<?php echo $HOME_URL ?>/showtype.php?brand=Suzuki">Suzuki</a></li>
        <li><a href="<?php echo $HOME_URL ?>/showtype.php?brand=Kawasaki">Kawasaki</a></li>
        <li><a href="<?php echo $HOME_URL ?>/showtype.php?brand=Yamaha">Yamaha</a></li>
      </ul>
    </span>

  </div>

</header>
