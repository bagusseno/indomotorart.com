<header class="common-header mid-header" id="mid-header">

  <div class="container">

    <!-- <span class="nav mid-nav menu-nav">
      <ul>
        <li><a href="<?php //echo $HOME_URL ?>">Beranda</a></li>
        <li><a href="<?php //echo $HOME_URL ?>/populer">Foto Populer</a></li>
        <li><a href="<?php //echo $HOME_URL ?>/baru">Foto Baru</a></li>
        <li><a href="<?php //echo $HOME_URL ?>/showtype.php?brand=Honda">Honda</a></li>
        <li><a href="<?php //echo $HOME_URL ?>/showtype.php?brand=Suzuki">Suzuki</a></li>
        <li><a href="<?php //echo $HOME_URL ?>/showtype.php?brand=Kawasaki">Kawasaki</a></li>
        <li><a href="<?php //echo $HOME_URL ?>/showtype.php?brand=Yamaha">Yamaha</a></li>
      </ul>
    </span> -->

    <div id="main-main">
      <div id="main-box">
        <div id="search-box" class="mb">
          <form id="search-form" method="get" action="http://indomotorart.com/search.php">
            <input type="text" id="search-input" name="keyword" placeholder="Cari sesuatu..."/>
            <button type="submit" id="search-submit"><a class="fa fa-search"></a></button>
        </div>
        <div id="menu-list" class="mb">
          <span><a href="http://indomotorart.com/showtype.php?brand=Honda">Honda</a></span>
          <span><a href="http://indomotorart.com/showtype.php?brand=Yamaha">Yamaha</a></span>
          <span><a href="http://indomotorart.com/showtype.php?brand=Kawasaki">Kawasaki</a></span>
          <span><a href="http://indomotorart.com/showtype.php?brand=Suzuki">Suzuki</a></span>
        </div>

      </div>
    </div>

    <div id="menu-list-2" class="mb">
      <span><a href="http://indomotorart.com/populer">Foto Populer</a></span>
      <span>|</span>
      <span><a href="http://indomotorart.com/baru">Foto Baru</a></span>
    </div>

  </div>

</header>
