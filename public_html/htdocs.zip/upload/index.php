<?php
require_once($_SERVER['DOCUMENT_ROOT'] . '/function/account.php');
if(isset($_POST['title'])) {
  require_once('upload.php');
}
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Upload - IndoMotorStyle</title>
    <?php
    require_once($_SERVER['DOCUMENT_ROOT'] . '/asset.php');
    require_once($_SERVER['DOCUMENT_ROOT'] . '/function/database.php');
    require_once($_SERVER['DOCUMENT_ROOT'] . '/function/session.php');

    if(!is_user_logged_in()) {
      header("Location: http://indomotorart.com");
      exit;
    }
    if(get_user_meta('token') != "activated") {
      header("Location: http://indomotorart.com/akun/verifikasi");
      exit;
    }

    // $nickname = get_user_meta('nickname');
    // $brand = get_user_meta('brand');
    // $tipe = get_user_meta('tipe');
    // $daerah = get_user_meta('daerah');
    //
    // if($nickname == null) {
    //   $nickname = "";
    // }
    // if($brand == null) {
    //   $brand = "";
    // }
    // if($tipe == null) {
    //   $tipe = "";
    // }
    // if($daerah == null) {
    //   $daerah = "";
    // }

    $msg_upload = "";
    $msg_title = "";
    $msg_motor = "";
    $msg_mod = "";

    ?>
  </head>
  <body>

    <?php require_once($_SERVER['DOCUMENT_ROOT'] . '/parts/top/top-header-2.php'); ?>
    <div class="page">
      <div class="container">
        <h1>Upload</h1>

        <form id="upload-form" method="POST" action="" enctype="multipart/form-data">
          <div class="col-12" id="left">
              <dl class="errMsg" id="msg-upload"><?php echo $msg_upload ?></dl>
              <dl class="upload-wrapper" style="max-width: 100%; border: 1px solid #ccc; min-height: 294px;display: flex; justify-content: center; align-items: center; flex-wrap: wrap">
                <dt id="img-field" class="u-side" style="display: none">
                  <img src="" id="img-file"/>
                </dt>
                <dt id="upload-file" class="u-side" style="position: absolute">
                  <label for="upload"><a id="upload-link" class="btn fa fa-plus" style="border:1px solid;cursor:pointer">Upload</a></label>
                  <input type="file" name="upload" id="upload" style="display: none" accept="image/*"></input>
                </dt>
              </dl>
              <label for="upload" id="ganti-link" style=" margin: 0 auto; display: none; margin-top: 11px; "><a class="btn fa fa-edit" style="border:1px solid;cursor:pointer">Ganti</a></label>
          </div>

          <div class="col-12" id="form">
            <dl class="form-group">
              <dt style="display:grid">
                <span class="form-label">
                  <label>Judul</label> <span class="errMsg" id="msg-title"/>
                </span>
                <span class="form-input">
                  <input type="text" name="title" id="title" value=""/>
                </span>
              </dt>
              <dt><p><small>Contoh: Honda Vario Ring 17 Tampak Depan</small></p></dt>
            </dl>
            <dl class="form-group">
              <dt style="display:grid">
                <span class="form-label">
                  <label>Brand dan Tipe Motor</label> <span class="errMsg" id="msg-motor"/>
                </span>
                <span class="form-input">
                  <select name="brand" id="motor">
                    <option value="" disabled selected>Pilih Brand</option>
                    <option value="honda">Honda</option>
                    <option value="yamaha">Yamaha</option>
                    <option value="kawasaki">Kawasaki</option>
                    <option value="suzuki">Suzuki</option>
                  </select>
                  <br><br>
                  <select id="yamaha" name="yamaha" class="tipe" style="display:none">
                    <option value='' disabled selected>Pilih tipe</option>
                    <option value='Aerox 125 LC'>Aerox 125 LC</option>
                    <option value='All new Soul GT 125'>All new Soul GT 125</option>
                    <option value='Grand Filano'>Grand Filano</option>
                    <option value='GT 125'>GT 125</option>
                    <option value='Jupiter MX'>Jupiter MX</option>
                    <option value='Jupiter z1'>Jupiter z1</option>
                    <option value='Mio M3 125'>Mio M3 125</option>
                    <option value='Mio Z'>Mio Z</option>
                    <option value='MT-09'>MT-09</option>
                    <option value='MT-09 Tracer'>MT-09 Tracer</option>
                    <option value='MT-25'>MT-25</option>
                    <option value='MX king'>MX king</option>
                    <option value='New Byson Fi'>New Byson Fi</option>
                    <option value='New Fino 125'>New Fino 125</option>
                    <option value='New Vixion'>New Vixion</option>
                    <option value='Nmax'>Nmax</option>
                    <option value='R1'>R1</option>
                    <option value='R-15'>R-15</option>
                    <option value='R-25'>R-25</option>
                    <option value='R6'>R6</option>
                    <option value='TMAX'>TMAX</option>
                    <option value='Vega Force'>Vega Force</option>
                    <option value='WR250R'>WR250R</option>
                    <option value='Xabre'>Xabre</option>
                    <option value='X-Ride'>X-Ride</option>
                  </select>
                  <select id="honda" name="honda" class="tipe" style="display:none">
                    <option value='' disabled selected>Pilih tipe</option>
                    <option value='All new supra GTR'>All new supra GTR</option>
                    <option value='Beat'>Beat</option>
                    <option value='Beat pop'>Beat pop</option>
                    <option value='Blade 125 FI'>Blade 125 FI</option>
                    <option value='CB150R'>CB150R</option>
                    <option value='CBR 150 R'>CBR 150 R</option>
                    <option value='CBR 250'>CBR 250</option>
                    <option value='MegaPro Fi'>MegaPro Fi</option>
                    <option value='new Supra X '>new Supra X </option>
                    <option value='Revo'>Revo</option>
                    <option value='Scoopy'>Scoopy</option>
                    <option value='Sonic 150R'>Sonic 150R</option>
                    <option value='Spacy'>Spacy</option>
                    <option value='Vario 110 Fi'>Vario 110 Fi</option>
                    <option value='Vario 125 '>Vario 125 </option>
                    <option value='Vario 150'>Vario 150</option>
                    <option value='Verza'>Verza</option>
                  </select>
                  <select id="kawasaki" name="kawasaki" class="tipe" style="display:none">
                    <option value='' disabled selected>Pilih tipe</option>
                    <option value='Athlete PRO'>Athlete PRO</option>
                    <option value='D-Tracker'>D-Tracker</option>
                    <option value='D-tracker SE'>D-tracker SE</option>
                    <option value='D-TRACKER X'>D-TRACKER X</option>
                    <option value='ER-6n'>ER-6n</option>
                    <option value='Estrella'>Estrella</option>
                    <option value='KSR 110'>KSR 110</option>
                    <option value='KSR PRO'>KSR PRO</option>
                    <option value='Ninja 1000'>Ninja 1000</option>
                    <option value='Ninja 250'>Ninja 250</option>
                    <option value='Ninja 650'>Ninja 650</option>
                    <option value='Ninja H2'>Ninja H2</option>
                    <option value='Ninja R'>Ninja R</option>
                    <option value='Ninja RR'>Ninja RR</option>
                    <option value='Ninja SS'>Ninja SS</option>
                    <option value='Ninja ZX-10R'>Ninja ZX-10R</option>
                    <option value='Ninja ZX-14R'>Ninja ZX-14R</option>
                    <option value='Ninja ZX-6R'>Ninja ZX-6R</option>
                    <option value='Pulsar 200NS'>Pulsar 200NS</option>
                    <option value='Versys 1000'>Versys 1000</option>
                    <option value='Versys 650'>Versys 650</option>
                    <option value='Vulcan S'>Vulcan S</option>
                    <option value='Vulcan S SE'>Vulcan S SE</option>
                    <option value='W800'>W800</option>
                    <option value='Z1000'>Z1000</option>
                    <option value='Z125 PRO'>Z125 PRO</option>
                    <option value='Z250'>Z250</option>
                    <option value='Z250SL'>Z250SL</option>
                    <option value='Z800'>Z800</option>
                  </select>
                  <select id="suzuki" name="suzuki" class="tipe" style="display:none">
                    <option value='value=' disabled selected>Pilih tipe</option>
                    <option value='Address'>Address</option>
                    <option value='BURGMAN 200'>BURGMAN 200</option>
                    <option value='Hayabusa'>Hayabusa</option>
                    <option value='Satria'>Satria</option>
                    <option value='Suzuki Inazuma R'>Suzuki Inazuma R</option>
                    <option value='V-Strom 650'>V-Strom 650</option>
                  </select>
                </span>
              </dt>
              <dt><p><small>Foto yang Anda upload boleh berbeda dengan motor andalan Anda. Pastikan brand dan tipe motor yang Anda masukkan sama dengan pada foto. </small></p></dt>
            </dl>
            <dl class="form-group">
              <dt style="display:grid">
                <span class="form-label">
                  <label>Spesifikasi modifikasi</label> <span class="errMsg" id="msg-mod"/>
                </span>
                <span class="form-input">
                  <input type="text" name="mod" id="mod" value=""/>
                </span>
              </dt>
              <dt><p><small>Jika berkenan, Anda bisa menjelaskan detail part-part apa saja yang dimodifikasi beserta merk.</small></p></dt>
            </dl>
            <dl class="form-group">
              <dt style="display:grid">
                <span class="form-label">
                  <label>Caption/Keterangan</label> <span class="errMsg" id="msg-caption"/>
                </span>
                <span class="form-input">
                  <input type="text" name="caption" id="caption" value=""/>
                </span>
              </dt>
              <dt><p><small>Jika mau, Anda bisa menambahkan caption atau keterangan mengenai foto Anda.</small></p></dt>
            </dl>
            <dl class="errMsg" id="allError"></dl>
            <dl class="" id="message"></dl>
            <dl class="form-group msg" id="msg" style="border:0"></dl>
            <dl class="" id="submit">
              <dt class="form-input">
                <input type="hidden" id="input-tipe" name="tipe" value=""/>
                <input type="submit" class="btn" value="Upload"/>
              </dt>
            </dl>
          </div>
        </form>
      </div>
    </div>
    <?php require_once($_SERVER['DOCUMENT_ROOT'] . '/parts/bottom.php'); ?>

  </body>
  <style>
  .col-12 {
    float: left;
    box-sizing: border-box;
    margin-top: 20px;
  }
  .fa-home:before, .fa-image:before, .fa-star:before {
    padding-right: 3px;
  }
  #form {
    padding-left: 10px;
    margin-bottom: 20px;
  }
  @media all and (max-width: 700px) {
    #form {
      float: unset;
      width: 100%
    }
    .col-12 {
      width: 100%;
      float: unset!important;
    }
  }
  #left {
    padding-right: 10px;
    float: left;
  }
  #img-field img {
    max-width: 100%;
  }
  .hallain {
    font-size: 30px;
    margin-top: 20px;
    text-decoration: none;
    max-width: 250px;
    display: table;
  }
  select {
    font-size: 20px;
  }
  #form input, select {
    float: right;
  }
  .form-group {
    padding-bottom: 25px;
    border-bottom: 1px solid #ccc;
  }
  .form-label {
    font-size: 20px;
  }
  .errMsg {
    font-size: 12px;
  }
  </style>
  <script type="text/javascript">

  $(document).ready(function() {
    // image preview
    $("#upload").unbind("change").bind("change", function() {

      if(this.files && this.files[0]) {
        var reader = new FileReader();
        reader.onload = function (e) {
          $("#img-file").attr("src", e.target.result);
          $("#img-field").fadeIn("fast");
          if($("#img-file").attr("src") != ""){
            $("#upload-link").fadeOut("fast");
            $("#ganti-link").css("display","table");
          } else {
            $("#upload-link").fadeIn("fast");
            $("#ganti-link").fadeOut("fast");
          }
        }
        reader.readAsDataURL(this.files[0]);
      }
    })
    var merk = $("#motor").val();
    var tipe = $(merk).val();

    $("#motor").on("change", function() {
      console.log("Change");
      merk = $("#motor").val();
      tipe = $("#" + merk).val();
      $("#input-tipe").val(tipe);
      console.log(merk + tipe);
      if(merk == "honda") {
        tipe =
        $(".tipe").css("display", "none");
        $("#honda").css("display", "block");
      }
      if(merk == "yamaha") {
        $(".tipe").css("display", "none");
        $("#yamaha").css("display", "block");
      }
      if(merk == "kawasaki") {
        $(".tipe").css("display", "none");
        $("#kawasaki").css("display", "block");
      }
      if(merk == "suzuki") {
        $(".tipe").css("display", "none");
        $("#suzuki").css("display", "block");
      }
      if(merk == "") {
        $(".tipe").css("display", "none");
      }
    })

    $(".tipe").change(function() {
      merk = $("#motor").val();
      tipe = $("#" + merk).val();
      $("#input-tipe").val(tipe);
      console.log(tipe);
    })


    $("#upload-form").unbind("submit").bind("submit", function(e) {
      e.preventDefault();
      // variables
      var upload = $("#upload");
      var title = $("#title");
      var motor = $("#motor");
      var mod = $("#mod");
      var caption = $("#caption");
      // error messages
      var msg_upload = $("#msg-upload");
      var msg_title = $("#msg-title");
      var msg_motor = $("#msg-motor");
      var msg_mod  = $("#msg-mod");
      var msg_caption = $("#msg-caption");
      // error counter
      var error = 0;
      // validating
      if(upload.val() == "") {
        msg_upload.html("Anda belum memilih gambar");
        error++;
      } else {
        msg_upload.html("");
      }
      if(title.val() == "") {
        msg_title.html("Anda belum memasukkan judul");
        error++;
      } else {
        msg_title.html("");
      }
      if(motor.val() == null) {
        msg_motor.html("Anda belum memilih motor");
        error++;
      } else {
        msg_motor.html("");
      }

      if(error == 0) {
        this.submit();
      }
    })
    // $("#motor").change();

    // $("#complete-form").on("submit", function(e) {
    //   e.preventDefault();
    //   console.log("SAD");
    //   tipe = merk;
    //   if(merk == "honda") {
    //     tipe = $("#honda").val();
    //   }
    //   if(merk == "yamaha") {
    //     tipe = $("#yamaha").val();
    //   }
    //   if(merk == "kawasaki") {
    //     tipe = $("#kawasaki").val();
    //   }
    //   if(merk == "suzuki") {
    //     tipe = $("#suzuki").val();
    //   }
    //   var data = {
    //     nickname  : $("#nickname").val(),
    //     brand     : $("#motor").val(),
    //     tipe      : tipe,
    //     daerah    : $("#daerah").val()
    //   }
    //   $("#msg").html("Mengirim...");
    //   $.ajax({
    //     type: "POST",
    //     url: "http://indomotorart.com/function/setup.php",
    //     data: data,
    //     success: function(r) {
    //       console.log("KJSAKJSAD");
    //       if(r == "fail") {
    //         $("#msg").html("Terjadi kesalahan. Harap refresh dan ulangi.");
    //       }
    //       if(r == "success") {
    //         $("#msg").html("Berhasil!");
    //       }
    //     },
    //     error: function() {
    //       $("#msg").html("Terjadi kesalahan. Harap refresh dan ulangi.");
    //     }
    //   })
    // })
  })
  </script>
</html>
