<?php
require_once($_SERVER['DOCUMENT_ROOT'] . '/function/session.php');
require_once($_SERVER['DOCUMENT_ROOT'] . "/function/strings.php");

if(!empty($_FILES['upload']['name']) && !empty($_POST['title']) && !empty($_POST['brand']) && !empty($_POST['tipe'])) {

  $img = $_FILES['upload'];
  $title = mysql_real_escape_string($_POST['title']);
  $brand = mysql_real_escape_string($_POST['brand']);
  $tipe = mysql_real_escape_string($_POST['tipe']);
  $mod = mysql_real_escape_string($_POST['mod']);
  $cap = mysql_real_escape_string($_POST['caption']);
  $imgurl;
  // validating
  $file = $img['tmp_name'];
  if(file_exists($file)) {
    $imgsize = getimagesize($file);
    if(!$imgsize || $imgsize === FALSE) {
      $msg_upload = "Anda memasukkan tipe gambar yang salah!";
    } else {
      $uniqid = uniqid();
      $imgurl = $_SERVER['DOCUMENT_ROOT'] . "/asset/photos/" . $uniqid . str_replace(" ", "-", $img['name']);
      $newImg = move_uploaded_file($file, $imgurl);
      $imgurl = "http://indomotorart.com/asset/photos/" . $uniqid . str_replace(" ", "-", $img['name']);
      if(!$newImg) {
        $msg_upload = "Terjadi error";
      }
    }
  }

  if($newImg) {
    $userID = $_SESSION['user'];
    $nick = get_user_meta('nickname');
    if($nick == "" || $nick == null || empty($nick)) {
      $nick = get_user_meta('username');
    }
    // create new safe url
    $url = preg_replace("/[^a-zA-Z0-9 ]/", "", $title . uniqid());
    $url = rtrim($url);
    $url = str_replace(" ", "-", $url);
    // manage tags
    $tags = extract_tag($cap, 0);
    // replace each of tags with link included
    if($tags != "" || $tags != NULL) {
      foreach($tags as $tag) {
        $noTag = str_replace("#", "", $tag);
        $cap = str_replace($tag, '<a href="' . $HOME_URL . '/search.php?tag=' . $noTag . '">' . $tag . '</a>', $cap);
      }
    }
    $tags = serialize($tags);

    $inputData = $conn->query("INSERT INTO post SET userID='$userID', url='$url', title='$title', brand='$brand', tipe='$tipe', modspec='$mod', content='$cap', tags='$tags', imgsrc='$imgurl'");
    $updateUser = $conn->query("UPDATE user SET rep = rep + 5 WHERE ID='$userID'");
    // checking the title
    $totalUserPost = $conn->query("SELECT * FROM post WHERE userID='$userID'");
    $totalUserPost = $totalUserPost->num_rows;
    if($totalUserPost >= 24) {
      set_user_meta("title", "3");
    }
    elseif($totalUserPost >= 14) {
      set_user_meta("title", "2");
    }
    elseif($totalUserPost >= 4) {
      set_user_meta("title", "1");
    }
    if(!$inputData && !$updateUser) {
      echo '<script>alert("Maaf! Terjadi kesalahan. Harap refresh dan ulangi.")</script>';
    } else {
      header("Location: http://indomotorart.com");
      exit;
    }
  }
  echo "YEYH GA ADA ERROR";
}

?>
