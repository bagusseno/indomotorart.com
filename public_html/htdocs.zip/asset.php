<?php $css_ver = 1.0 ?>
<link type="text/css" rel="stylesheet" href="http://indomotorart.com/asset/style/header-style.css?v=<?php echo $css_ver ?>"/>
<link type="text/css" rel="stylesheet" href="http://indomotorart.com/asset/style/main-style.css?v=<?php echo $css_ver ?>"/>
<link type="text/css" rel="stylesheet" href="http://indomotorart.com/asset/style/footer-style.css?v=<?php echo $css_ver ?>"/>
<link type="text/css" rel="stylesheet" href="http://indomotorart.com/asset/style/style.css?v=<?php echo $css_ver ?>"/>
<link type="text/css" rel="stylesheet" href="http://indomotorart.com/asset/style/responsive.css?v=<?php echo $css_ver ?>"/>
<script src="https://code.jquery.com/jquery-3.2.1.min.js" integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4=" crossorigin="anonymous"></script>
<script type="text/javascript" src="http://indomotorart.com/asset/script/main-script.js?"></script>
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
